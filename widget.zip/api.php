<?php
    echo 'Hello Wrold';
    // header('Content-Type: application/json; charset=utf-8');
    //header('content-encoding: gzip');

    //ob_start("ob_gzhandler");
        
        // $config['subdomain']        = 'hellerandrei1985';
        // $config['client_id']        = '87b99d22-4c6c-4a17-978b-6ef26af05f5e';
        // $config['client_secret']    = 'yGloysW6IvlG9TfYgaVKiFitCu14cuEV8xIQj8GzNRejbgQaXEk5J1NMvQSykgid';
        // $config['code']             = 'dsrr4gsd9h2q1ple4qu0iqnbgnfy5ozwcigliu8x';
        // $config['redirect_uri']     = 'https://hellerandrei1985.amocrm.com/';

        // require_once ( 'includes/class.own.api.php' );
        // $connection = new WidgetApi();		
		// $GGET 		= $_GET;		
		// $response 	= $connection->handler($GGET);        
        // echo $response;

	//ob_end_flush();	
?>